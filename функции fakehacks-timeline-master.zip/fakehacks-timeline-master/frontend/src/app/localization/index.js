import cs from './cs.yml';

export const languages = ['cs'];

export default {
    cs,
};
