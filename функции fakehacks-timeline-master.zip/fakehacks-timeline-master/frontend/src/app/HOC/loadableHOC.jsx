import loadableFactory from 'ackee-frontend-toolkit/lib/HOC/loadable';
import Loader from '../components/Loader';

export default loadableFactory(Loader);

