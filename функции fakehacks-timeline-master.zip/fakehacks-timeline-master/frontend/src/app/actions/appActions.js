import types from './actionTypes';

export function closeNotification() {
    return {
        type: types.app.CLOSE_NOTFICATION,
    };
}


