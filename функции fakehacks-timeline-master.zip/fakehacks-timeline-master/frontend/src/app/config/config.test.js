import config from './config.development';

export default config;
