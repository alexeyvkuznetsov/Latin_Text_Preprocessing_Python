const config = {
    api: {
        base: 'https://abibuch',
    },
};

export default config;
