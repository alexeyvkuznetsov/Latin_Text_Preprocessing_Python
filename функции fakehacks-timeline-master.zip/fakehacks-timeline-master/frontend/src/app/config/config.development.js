const config = {
    api: {
        base: 'https://abibuch',
    },
    devTools: true,
};

export default config;
