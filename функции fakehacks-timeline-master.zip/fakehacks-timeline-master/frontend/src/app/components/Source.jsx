import React from 'react';
import PropTypes from 'prop-types';

import SourceForm from '../containers/SourceForm';
//import SourceForm from './SourceForm';

const Source = props => {
    return (
        <div>
            <SourceForm />
        </div>
    );
};

Source.propTypes = {

};

export default Source;
